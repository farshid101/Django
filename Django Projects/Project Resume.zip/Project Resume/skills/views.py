from django.shortcuts import render

# Create your views here.
def skill(response):

    return render(response ,"skills/skills.html",{})